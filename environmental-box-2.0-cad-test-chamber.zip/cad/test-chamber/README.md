# Test Chamber CAD Files

Acrylic enclosure for the Environmental Box 2.0 test chamber.

## Assembly

- `Prototype2_Assem.SLDASM` - Complete assembly file (open this in SolidWorks to see full chamber)

## Acrylic Panels (1/4" clear acrylic)

| File | Description |
|------|-------------|
| `Prototype2_Acrylic_Top.SLDPRT` | Top panel |
| `Prototype2_Acrylic_Bottom.SLDPRT` | Bottom panel |
| `Prototype2_Acrylic_FrontBack.SLDPRT` | Front and back panels (identical) |
| `Prototype2_Acrylic_LeftSide.SLDPRT` | Left side panel |
| `Prototype2_Acrylic_RightSide.SLDPRT` | Right side panel (includes door cutout) |

## Laser Cut Files (DXF)

Ready-to-cut files for laser cutter:
- `Prototype2_Acrylic_Bottom.DXF`
- `Prototype2_Acrylic_FrontBack.DXF`
- `Prototype2_Acrylic_LeftSide.DXF`

## Seals & Hardware

- `Prototype2_Acrylic_DoorSeal.SLDPRT` - Gasket for specimen door
- `Prototype2_Acrylic_TopSeal.SLDPRT` - Top panel seal
- `Prototype2_Legv1.SLDPRT` - Support legs (3D print or machine)

## Fabrication Notes

- Material: 1/4" (6.35mm) clear acrylic
- Assembly: Use acrylic cement (e.g., Weld-On 4) for permanent bonds
- Chamber dimensions: 12 × 8 × 6 inches internal
- Includes holes for:
  - Airflow inlet/outlet ports
  - Sensor pass-through
  - PTC heater mounting at corners
