# Valve CAD Files

Custom 3D-printed valve assemblies for airflow control. Print with standard PLA/PETG settings.

## 3-Way Valves
Route airflow between humidifier and dehumidifier pathways.

- `valve_body_A.STL` + `valve_body_B.STL` - Main housing (print both halves)
- `valve_turn.STL` - Internal rotating element
- `cylinder_valve_body_A.STL` + `cylinder_valve_body_B.STL` - Cylindrical variant housing
- `cylinder_valve_turn.STL` - Cylindrical variant rotor

## Gate Valves
Enable/disable airflow into the test chamber.

- `cylinder_gate_body_A.STL` + `cylinder_gate_body_B.STL` - Gate housing halves
- `gate_valve_turn.STL` - Gate actuator element

## Assembly Notes
- Both valve types include internal mechanical stops
- Designed for 2" tubing diameter
- Use DC motors for actuation (no precision control needed due to mechanical stops)
