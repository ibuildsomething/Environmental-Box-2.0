# Humidifier CAD Files

Ultrasonic piezoelectric humidifier housing.

## Files

- `humdifier_prototype.SLDPRT` - SolidWorks part file for humidifier housing

## Design Features

- **Baffled reservoir** - Separates fill reservoir from transducer area, allowing refilling during operation without releasing mist
- **Cylindrical mist chamber** - Aligns with 2" system tubing for efficient vapor delivery
- **Sealed construction** - Prevents ambient air intrusion that plagued v1.0

## Print Settings
- **Critical: Use 100% infill** to prevent water seepage through layer lines
- Apply acrylic sealant to interior surfaces after printing
- Material: PETG recommended for water resistance

## Components Needed
- Piezoelectric ultrasonic transducer (24V, 25-35W)
- Water reservoir
- Tube fittings for airflow connection
