# Dehumidifier CAD Files

Modular desiccant dehumidifier with hot-swap capability.

## SolidWorks Source Files

- `Dehumidifier_Assembly.SLDASM` - Complete assembly (open this first)
- `Core_V4.SLDPRT` - Main desiccant container body
- `Closed_Cap_V4.SLDPRT` - Sealed cap
- `Dehumidifier_Base.SLDPRT` - Mounting base/fixture
- `Dehumidifier_Handle.SLDPRT` - Handle for hot-swap removal

## STL Files (Ready to Print)

- `core2.STL` - Main desiccant container body
- `actual_funnel1.STL` - Air inlet funnel
- `closed_cap1.STL` - Sealed cap for operation
- `closed_cap_w_tube_attatchment.STL` - Cap with tube fitting (inlet)
- `closed_cap_w_tube_attatchment2.STL` - Cap with tube fitting (outlet)

## Print Settings
- Material: PLA or PETG
- Infill: 20-50% for caps, 100% for parts contacting desiccant
- Layer height: 0.2mm

## Assembly
1. Fill container with silica gel desiccant (~500g capacity)
2. Attach appropriate caps based on airflow direction
3. Container slides into holding fixture for tool-free swapping

## Maintenance
Desiccant supports 10+ consecutive tests before reactivation needed. Regenerate by heating silica gel to 120°C for 2 hours.
